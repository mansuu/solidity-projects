//Script for compiling and deploying solidity smart contract

const ethers = require("ethers");
const fs = require("fs-extra");
//import { JsonRpcProvider } from "ethers";

const privateKey =
  "0xfd205da1d7a63dea8573a1cf2bee15f4f5172313b82ff87512fa14f6e3069602";

async function main() {
  //http://127.0.0.1:7545
  const provider = new ethers.JsonRpcProvider("http://localhost:7545");
  const wallet = new ethers.Wallet(privateKey, provider);
  const abi = fs.readFileSync("./SimpleStorage_sol_SimpleStorage.abi", "utf8");
  const binary = fs.readFileSync(
    "./SimpleStorage_sol_SimpleStorage.bin",
    "utf8"
  );
  const contractFactory = new ethers.ContractFactory(abi, binary, wallet);
  console.log("Deploying Contract, please wait..........");
  const deploymentOptions = {
    gasLimit: 6721975,
  };
  const contract = await contractFactory.deploy(deploymentOptions);
  await contract.deploymentTransaction.wait(1);
  //console.log("deployment Receipt", deploymentReceipt);

  //   //Deploy contract as a transaction
  //   const tx = {
  // nonce : wallet.getTrans
  //   }

  const favNumber = await contract.retrievefavNumber();
  console.log("fav number", favNumber);
}

main()
  .then(() => {
    process.exit(0);
  })
  .catch((error) => {
    console.log(error.message);
    process.exit(1);
  });
